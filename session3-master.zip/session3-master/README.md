# session3
Session 3 for Kubernetes pods 
